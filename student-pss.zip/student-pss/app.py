from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from werkzeug.utils import secure_filename
from sqlalchemy.exc import OperationalError

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-ips-2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['UPLOAD_FOLDER'] = 'Uploads'
app.config['PLOTS_FOLDER'] = os.path.join('static', 'plots')
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Create folders
for folder in [app.config['UPLOAD_FOLDER'], app.config['PLOTS_FOLDER']]:
    if not os.path.exists(folder):
        os.makedirs(folder)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    student_id = db.Column(db.String(20), unique=True, nullable=True)

class StudentData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_rollno = db.Column(db.String(20), nullable=False)
    studentname = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    attendencelastsem = db.Column(db.Float, nullable=False)
    sub1 = db.Column(db.String(10), nullable=False)
    sub2 = db.Column(db.String(10), nullable=False)
    sub3 = db.Column(db.String(10), nullable=False)
    sub4 = db.Column(db.String(10), nullable=False)
    sub5 = db.Column(db.String(10), nullable=False)
    result = db.Column(db.String(1), nullable=False)  # P or F

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Load ML model and scaler
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model = None
scaler = None
try:
    model = joblib.load(os.path.join(BASE_DIR, 'student.pkl'))
    scaler = joblib.load(os.path.join(BASE_DIR, 'scaler.pkl'))
except FileNotFoundError as e:
    print(f"Error: {e}. Please run create_model.py to generate student.pkl and scaler.pkl in {BASE_DIR}")

# Initialize database with error handling
def init_db():
    try:
        with app.app_context():
            db.drop_all()  # Drop old tables to avoid schema conflicts
            db.create_all()
            print("Database initialized successfully. New site.db created with updated schema.")
    except Exception as e:
        print(f"Error initializing database: {e}")

init_db()

def generate_dashboard_plots(students):
    if not students:
        return
    # Convert to DataFrame
    data = [{
        'student_rollno': s.student_rollno,
        'studentname': s.studentname,
        'age': s.age,
        'attendencelastsem': s.attendencelastsem,
        'sub1': s.sub1,
        'sub2': s.sub2,
        'sub3': s.sub3,
        'sub4': s.sub4,
        'sub5': s.sub5,
        'result': s.result
    } for s in students]
    df = pd.DataFrame(data)
    
    # Plot 1: Pass/Fail Bar
    plt.figure(figsize=(6, 4))
    sns.countplot(x='result', data=df, palette='viridis')
    plt.title('Pass/Fail Distribution')
    plt.xlabel('Result (P=Pass, F=Fail)')
    plt.ylabel('Count')
    plt.tight_layout()
    plt.savefig(os.path.join(app.config['PLOTS_FOLDER'], 'pass_fail_bar.png'))
    plt.close()
    
    # Plot 2: Subject Pass Rates Pie
    subjects = ['sub1', 'sub2', 'sub3', 'sub4', 'sub5']
    pass_rates = [1 - (df[sub].str.lower().isin(['f', 'fail', 'failth']).mean()) for sub in subjects]
    plt.figure(figsize=(6, 4))
    plt.pie(pass_rates, labels=['Sub1', 'Sub2', 'Sub3', 'Sub4', 'Sub5'], autopct='%1.1f%%', colors=sns.color_palette('pastel'))
    plt.title('Subject Pass Rates')
    plt.tight_layout()
    plt.savefig(os.path.join(app.config['PLOTS_FOLDER'], 'subject_pass_pie.png'))
    plt.close()
    
    # Plot 3: Correlation Heatmap
    df['result_numeric'] = df['result'].map({'P': 1, 'F': 0})
    corr = df[['age', 'attendencelastsem', 'result_numeric']].corr()
    plt.figure(figsize=(6, 4))
    sns.heatmap(corr, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
    plt.title('Correlation Heatmap')
    plt.tight_layout()
    plt.savefig(os.path.join(app.config['PLOTS_FOLDER'], 'correlation_heatmap.png'))
    plt.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard' if current_user.role == 'teacher' else 'student_profile'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard' if user.role == 'teacher' else 'student_profile'))
        flash('Invalid username or password.', 'error')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        student_id = request.form.get('student_id')
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'error')
        elif role == 'student' and not student_id:
            flash('Student ID is required for student accounts.', 'error')
        else:
            user = User(
                username=username,
                password_hash=generate_password_hash(password),
                role=role,
                student_id=student_id if role == 'student' else None
            )
            db.session.add(user)
            db.session.commit()
            flash('Account created! Please log in.', 'success')
            return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'teacher':
        flash('Access denied.', 'error')
        return redirect(url_for('student_profile'))
    try:
        students = StudentData.query.all()
        total_students = len(students)
        pass_count = sum(1 for s in students if s.result == 'P')
        pass_ratio = (pass_count / total_students * 100) if total_students else 0
        avg_age = sum(s.age for s in students) / total_students if total_students else 0
        avg_attendance = sum(s.attendencelastsem for s in students) / total_students if total_students else 0
        generate_dashboard_plots(students)
        return render_template('dashboard.html', students=students, total_students=total_students,
                             pass_ratio=pass_ratio, avg_age=avg_age, avg_attendance=avg_attendance)
    except OperationalError as e:
        flash('Database error: Please upload a valid CSV to initialize student data.', 'error')
        return render_template('dashboard.html', students=[], total_students=0,
                             pass_ratio=0, avg_age=0, avg_attendance=0)

@app.route('/student_profile')
@login_required
def student_profile():
    if current_user.role != 'student':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    try:
        student_data = StudentData.query.filter_by(student_rollno=current_user.student_id).first()
        return render_template('student_profile.html', student=student_data)
    except OperationalError as e:
        flash('Database error: No student data available.', 'error')
        return render_template('student_profile.html', student=None)

@app.route('/ai')
@login_required
def ai_page():
    if model is None or scaler is None:
        flash('Prediction model not available. Please contact the administrator.', 'error')
    return render_template('ai.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if current_user.role != 'teacher':
        flash('Access denied.', 'error')
        return redirect(url_for('student_profile'))
    if 'file' not in request.files:
        flash('No file uploaded.', 'error')
        return redirect(url_for('ai'))
    file = request.files['file']
    if file.filename.endswith('.csv'):
        try:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            df = pd.read_csv(file_path)
            required_cols = ['student_rollno', 'studentname', 'age', 'attendencelastsem', 'sub1', 'sub2', 'sub3', 'sub4', 'sub5', 'result']
            if not all(col in df for col in required_cols):
                flash('CSV must contain student_rollno, studentname, age, attendencelastsem, sub1, sub2, sub3, sub4, sub5, result.', 'error')
                return redirect(url_for('ai'))
            # Validate result
            for idx, row in df.iterrows():
                grades = [row[f'sub{i}'] for i in range(1, 6)]
                is_passing = all(g.lower() not in ['f', 'fail', 'failth'] for g in grades)
                expected_result = 'P' if is_passing else 'F'
                if row['result'] != expected_result:
                    flash(f"Invalid result for {row['student_rollno']}: Expected {expected_result}, got {row['result']}.", 'error')
                    return redirect(url_for('ai'))
            # Process CSV
            StudentData.query.delete()  # Clear old data
            for idx, row in df.iterrows():
                student = StudentData(
                    student_rollno=row['student_rollno'],
                    studentname=row['studentname'],
                    age=row['age'],
                    attendencelastsem=row['attendencelastsem'],
                    sub1=row['sub1'],
                    sub2=row['sub2'],
                    sub3=row['sub3'],
                    sub4=row['sub4'],
                    sub5=row['sub5'],
                    result=row['result']
                )
                db.session.add(student)
            db.session.commit()
            flash('File processed and data saved!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error processing file: {str(e)}', 'error')
    else:
        flash('Please upload a valid CSV file.', 'error')
    return redirect(url_for('ai'))

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    if model is None or scaler is None:
        flash('Prediction model not available. Please contact the administrator.', 'error')
        return render_template('ai.html')
    try:
        RollNo = request.form['RollNo']
        attendance = float(request.form['attendance'])
        homework = float(request.form['homework'])
        midterm = float(request.form['midterm'])
        md = float(request.form['md'])
        if not all(0 <= x <= 100 for x in [attendance, homework, midterm, md]):
            flash('Values must be between 0 and 100.', 'error')
            return render_template('ai.html', RollNo=RollNo)
    except (ValueError, KeyError):
        flash('Please enter valid numeric values.', 'error')
        return render_template('ai.html', RollNo=request.form.get('RollNo', ''))
    
    new_student = [[attendance, homework, midterm, md]]
    new_student_scaled = scaler.transform(new_student)
    prediction = model.predict(new_student_scaled)[0]
    prediction_result = "Pass" if prediction == 1 else "Fail"
    return render_template('ai.html', 
                         prediction=prediction_result, 
                         RollNo=RollNo,
                         attendance=attendance, 
                         homework=homework, 
                         midterm=midterm, 
                         md=md)

if __name__ == '__main__':
    app.run(debug=True)