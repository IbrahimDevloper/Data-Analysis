import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import joblib

# Sample data
data = {
    'attendance': [95.5, 70.0, 85.0, 60.0, 90.0, 82.5, 65.0, 92.0, 78.0, 55.0, 88.0, 72.0],
    'homework': [90.0, 65.0, 80.0, 55.0, 85.0, 78.0, 60.0, 88.0, 72.0, 50.0, 83.0, 68.0],
    'midterm': [85.0, 60.0, 75.0, 50.0, 80.0, 73.0, 55.0, 90.0, 68.0, 45.0, 82.0, 62.0],
    'md': [80.0, 55.0, 70.0, 45.0, 75.0, 70.0, 50.0, 85.0, 70.0, 40.0, 78.0, 60.0],
    'result': [1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0]
}
df = pd.DataFrame(data)

# Features and target
X = df[['attendance', 'homework', 'midterm', 'md']]
y = df['result']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_scaled, y)

# Save
joblib.dump(model, 'student.pkl')
joblib.dump(scaler, 'scaler.pkl')

print("Updated student.pkl and scaler.pkl created.")